@echo off
clip < "%~dp0server-command.txt"
echo The server command is copied! Go paste it into ZimaOS.
pause
