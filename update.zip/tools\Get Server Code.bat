@echo off
title FastLane - downloading server code to look at
cd /d "%~dp0.."
set GIT_LFS_SKIP_SMUDGE=1
set G=%CD%\git\cmd\git.exe
if exist server-peek rmdir /s /q server-peek
"%G%" clone --filter=blob:none --no-checkout --depth 1 https://gitlab.com/2009scape/2009scape.git server-peek
cd server-peek
"%G%" sparse-checkout set --no-cone "/Server/src/main/content/global/skill/" "/Server/src/main/core/api/" "/Server/src/main/core/game/event/"
"%G%" checkout
echo.
echo Done! You can close this window.
pause
