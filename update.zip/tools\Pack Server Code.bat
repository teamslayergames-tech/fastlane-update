@echo off
cd /d "%~dp0..\server-peek\Server\src\main"
tar -czf "%~dp0..\server-code.tgz" content\global\skill core\api core\game\event
echo Done! You can close this window.
pause
