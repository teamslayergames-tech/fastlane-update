# Shared helpers for the 2009scape one-click launcher (Windows PowerShell 5.1+)

$ErrorActionPreference = 'Stop'

$ProgressPreference = 'SilentlyContinue'

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12



$Base   = Split-Path -Parent $PSScriptRoot

$JdkDir = Join-Path $Base 'java17'

$GitDir = Join-Path $Base 'git'

$DlDir  = Join-Path $Base 'downloads'

$SrvDir = Join-Path $Base 'server-src'

$CliDir = Join-Path $Base 'client-src'

New-Item -ItemType Directory -Force -Path $DlDir | Out-Null



function Say($msg)  { Write-Host $msg -ForegroundColor Cyan }

function Fail($msg) { Write-Host "[!] $msg" -ForegroundColor Red; throw $msg }



function Download($url, $out) {

    & curl.exe -L --fail --retry 3 -o $out $url

    if ($LASTEXITCODE -ne 0) { Fail "Download failed: $url" }

}



function Ensure-Java {

    if (Test-Path (Join-Path $JdkDir 'bin\java.exe')) { Say 'Java 17 ready.' }

    else {

        Say 'Downloading Java 17 (private copy, one time only, ~190 MB)...'

        $zip = Join-Path $DlDir 'jdk17.zip'

        Download 'https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse' $zip

        $tmp = Join-Path $DlDir 'jdk_x'; Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue

        New-Item -ItemType Directory -Path $tmp | Out-Null

        & tar.exe -xf $zip -C $tmp; if ($LASTEXITCODE -ne 0) { Fail 'Could not unpack Java.' }

        Move-Item (Get-ChildItem $tmp -Directory | Select-Object -First 1).FullName $JdkDir

        Remove-Item $zip, $tmp -Recurse -Force

    }

    $env:JAVA_HOME = $JdkDir

    $env:Path = "$JdkDir\bin;$env:Path"

}



function Ensure-Git {

    if (Test-Path (Join-Path $GitDir 'cmd\git.exe')) { Say 'Git ready.' }

    else {

        Say 'Downloading portable Git (one time only)...'

        $rel = Invoke-RestMethod 'https://api.github.com/repos/git-for-windows/git/releases/latest' -Headers @{ 'User-Agent' = 'launcher' }

        $asset = $rel.assets | Where-Object { $_.name -like 'PortableGit-*-64-bit.7z.exe' } | Select-Object -First 1

        if (-not $asset) { Fail 'Could not find the portable Git download.' }

        $exe = Join-Path $DlDir 'PortableGit.7z.exe'

        Download $asset.browser_download_url $exe

        & $exe -y "-o$GitDir" | Out-Null

        Start-Sleep -Seconds 2

        if (-not (Test-Path (Join-Path $GitDir 'cmd\git.exe'))) { Fail 'Portable Git did not unpack correctly.' }

        Remove-Item $exe -Force

    }

    $env:Path = "$GitDir\cmd;$GitDir\mingw64\bin;$env:Path"

    & git lfs install --skip-repo | Out-Null

}



function Git-Clone($url, $dir, [switch]$Submodules) {

    if (Test-Path (Join-Path $dir '.git')) { return }

    Remove-Item -Recurse -Force $dir -ErrorAction SilentlyContinue

    $gitArgs = @('clone', '--depth', '1')

    if ($Submodules) { $gitArgs += '--recurse-submodules' }

    & git @gitArgs $url $dir

    if ($LASTEXITCODE -ne 0) { Remove-Item -Recurse -Force $dir -ErrorAction SilentlyContinue; Fail "Could not download $url" }

}



function Set-ConfValue($file, $key, $value) {

    $text = Get-Content -LiteralPath $file -Raw

    $pattern = "(?m)^(\s*$([regex]::Escape($key))\s*=\s*)[^\r\n#]*"

    if ($text -notmatch $pattern) { Write-Host "  (setting '$key' not found, skipped)"; return }

    $text = [regex]::Replace($text, $pattern, "`${1}$value ")

    Set-Content -LiteralPath $file -Value $text -NoNewline -Encoding ascii

}


function Read-ServerInfo($dir) {
    # server.txt: line1 host, line2 game port, line3 world-list/cache port
    $f = Join-Path $dir 'server.txt'
    if (Test-Path $f) {
        $l = @(Get-Content $f | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($l.Count -ge 3) { return @{ Host = $l[0]; Game = [int]$l[1]; Wl = [int]$l[2] } }
    }
    $old = Join-Path $dir 'host-ip.txt'
    if (Test-Path $old) { return @{ Host = (Get-Content $old -Raw).Trim(); Game = 43594; Wl = 43595 } }
    return $null
}

function Write-ClientConfig($path, $info) {
    $json = @"
{
    "ip_management": "$($info.Host)",
    "ip_address": "$($info.Host)",
    "world": 1,
    "server_port": $($info.Game),
    "wl_port": $($info.Wl),
    "js5_port": $($info.Wl),
    "mouseWheelZoom": true,
    "pluginsFolder": "$(((Join-Path $Base 'plugins') -replace '\\','/'))"
}
"@
    Set-Content -LiteralPath $path -Value $json -Encoding ascii
}

function Test-Port($h, $port) {
    $tcp = New-Object Net.Sockets.TcpClient
    try { return ($tcp.ConnectAsync($h, $port).Wait(5000) -and $tcp.Connected) } catch { return $false } finally { $tcp.Close() }
}

function Ensure-Client {
    Ensure-Java | Out-Host
    $jarPath = Join-Path $CliDir 'client\build\libs\client-1.0.0.jar'
    if (-not (Test-Path $jarPath)) {
        Ensure-Git
        Say 'Downloading the game client (one time)...'
        Git-Clone 'https://gitlab.com/2009scape/rt4-client.git' $CliDir -Submodules | Out-Host
        Say 'Building the client (a few minutes the first time)...'
        Push-Location $CliDir
        $env:_JAVA_OPTIONS = '--add-exports=java.base/sun.nio.ch=ALL-UNNAMED'
        & .\gradlew.bat jar --no-daemon | Out-Host
        $built = $LASTEXITCODE -eq 0
        Remove-Item Env:\_JAVA_OPTIONS -ErrorAction SilentlyContinue
        Pop-Location
        if (-not $built) { Fail 'The client build failed.' }
        if (-not (Test-Path $jarPath)) {
            $found = Get-ChildItem (Join-Path $CliDir 'client\build\libs') -Filter '*.jar' | Select-Object -First 1
            if ($found) { $jarPath = $found.FullName } else { Fail 'Client jar not found after build.' }
        }
    }
    Ensure-Plugins | Out-Host
    return $jarPath
}

function Ensure-Plugins {
    # Client add-ons: XP drops + total XP counter, scroll-wheel zoom + middle-mouse camera rotate
    $plugDir = Join-Path $Base 'plugins'
    $marker  = Join-Path $plugDir 'fastlane-plugins-v5.txt'
    if (Test-Path $marker) { return }
    $pp   = Join-Path $CliDir 'plugin-playground'
    $kt   = Join-Path $pp 'src\main\kotlin'
    if (-not (Test-Path (Join-Path $kt 'XPDropPlugin'))) { Say 'Client add-on sources not found - skipping.'; return }
    Say 'Setting up client add-ons (one time)...'
    # FastLane versions of add-ons shipped next to this script
    $over = Join-Path $PSScriptRoot 'plugins-src'
    if (Test-Path $over) {
        Get-ChildItem $over -Directory | ForEach-Object { New-Item -ItemType Directory -Force -Path (Join-Path $kt $_.Name) | Out-Null; Copy-Item (Join-Path $_.FullName '*') (Join-Path $kt $_.Name) -Recurse -Force }
    }
    # show the total XP box all the time, like OSRS
    $src  = Join-Path $kt 'XPDropPlugin\plugin.kt'
    $code = Get-Content -LiteralPath $src -Raw
    $code = $code.Replace('(GetData("xp-drop-alwaysShow") as? Boolean) ?: false', '(GetData("xp-drop-alwaysShow") as? Boolean) ?: true')
    Set-Content -LiteralPath $src -Value $code -Encoding utf8
    # ground item prices: use the built-in price list (no internet lookups)
    $gi = Join-Path $kt 'GroundItems\plugin.kt'
    if (Test-Path $gi) {
        $code = Get-Content -LiteralPath $gi -Raw
        $code = $code.Replace('private var useLiveGEPrices = true', 'private var useLiveGEPrices = false').Replace('GetData("ground-item-use-remote") as? Boolean ?: true', 'GetData("ground-item-use-remote") as? Boolean ?: false')
        Set-Content -LiteralPath $gi -Value $code -Encoding utf8
    }
    Push-Location $CliDir
    $env:_JAVA_OPTIONS = '--add-exports=java.base/sun.nio.ch=ALL-UNNAMED'
    & .\gradlew.bat :plugin-playground:classes --no-daemon | Out-Host
    $ok = $LASTEXITCODE -eq 0
    Remove-Item Env:\_JAVA_OPTIONS -ErrorAction SilentlyContinue
    Pop-Location
    $cls = Join-Path $pp 'build\classes\kotlin\main'
    if (-not $ok -or -not (Test-Path (Join-Path $cls 'XPDropPlugin\plugin.class'))) { Say 'Could not build the client add-ons - playing without them.'; return }
    if (Test-Path $plugDir) { Remove-Item $plugDir -Recurse -Force }
    foreach ($name in @('XPDropPlugin', 'BasicInputQOL', 'XPGlobesPlugin', 'GroundItems', 'SmartRoofs', 'EscClose', 'BetterShiftDrop', 'SlayerTrackerPlugin', 'TabReply', 'FastExchangeTab')) {
        if (-not (Test-Path (Join-Path $cls "$name\plugin.class"))) { continue }
        $dst = Join-Path $plugDir $name
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item (Join-Path $cls "$name\*") $dst -Recurse -Force
        Copy-Item (Join-Path $kt "$name\plugin.properties") $dst -Force
        $res = Join-Path $kt "$name\res"
        if (Test-Path $res) { Copy-Item $res $dst -Recurse -Force }
    }
    # XPDropPlugin uses KondoKit's @Exposed annotation - ship just that class
    $kk = Join-Path $cls 'KondoKit'
    if (Test-Path $kk) {
        $kdst = Join-Path $plugDir 'KondoKit'
        New-Item -ItemType Directory -Force -Path $kdst | Out-Null
        Get-ChildItem $kk -Filter 'Exposed*.class' | Copy-Item -Destination $kdst -Force
    }
    Set-Content -LiteralPath $marker -Value 'ok' -Encoding ascii
}

function Launch-Client($jarPath, $cfg) {
    $jarPath = @($jarPath | Where-Object { $_ -is [string] -and $_ -like '*.jar' })[-1]
    Say 'Launching the game...'
    # the client saves settings (volume, brightness, etc.) in %USERPROFILE%\2009scape - without it nothing is saved
    New-Item -ItemType Directory -Force -Path (Join-Path $env:USERPROFILE '2009scape') | Out-Null
    Start-Process -FilePath (Join-Path $JdkDir 'bin\javaw.exe') -ArgumentList @('-Dsun.java2d.uiScale=1', '--add-exports=java.base/java.lang=ALL-UNNAMED', '--add-exports=java.desktop/sun.awt=ALL-UNNAMED', '--add-exports=java.desktop/sun.java2d=ALL-UNNAMED', '--add-opens=java.desktop/sun.awt=ALL-UNNAMED', '--add-opens=java.desktop/sun.awt.windows=ALL-UNNAMED', '--add-opens=java.desktop/sun.java2d=ALL-UNNAMED', '--add-opens=java.base/java.lang=ALL-UNNAMED', '-jar', "`"$jarPath`"", '--config', "`"$cfg`"") -WorkingDirectory (Split-Path $jarPath)
}
