# Non-interactive version of play.ps1, run by launcher.ps1 (no Read-Host prompts).
# Exit codes: 0 = game launched, 1 = something went wrong, 2 = server unreachable, 3 = server.txt missing
. "$PSScriptRoot\common.ps1"
try {
    Say '=== FastLane ==='
    $info = Read-ServerInfo $Base
    if (-not $info) {
        Write-Host '[!] This package is missing server.txt. Ask your friend for a new package.' -ForegroundColor Red
        exit 3
    }
    Say "Server: $($info.Host):$($info.Wl)"
    if (-not (Test-Port $info.Host $info.Wl)) {
        Write-Host "[!] Can't reach the server right now." -ForegroundColor Red
        Write-Host '    The server is probably off - ask your friend to start it.' -ForegroundColor Yellow
        Write-Host '    (If it uses Tailscale, make sure Tailscale is running on your PC.)' -ForegroundColor Yellow
        exit 2
    }
    $cfg = Join-Path $Base 'client-config.json'
    Write-ClientConfig $cfg $info
    $jar = Ensure-Client
    Launch-Client $jar $cfg
    Say 'Game launched. Have fun!'
    exit 0
}
catch {
    Write-Host ''
    Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Yellow
    exit 1
}
