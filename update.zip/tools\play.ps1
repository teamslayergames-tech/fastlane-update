. "$PSScriptRoot\common.ps1"
try {
    Say '=== FastLane ==='
    $info = Read-ServerInfo $Base
    if (-not $info) { Fail 'This package is missing server.txt. Ask the server owner for a new copy of FastLane.' }
    Say "Server: $($info.Host):$($info.Wl)"
    if (-not (Test-Port $info.Host $info.Wl)) {
        Write-Host ''
        Write-Host "[!] Can't reach the server right now." -ForegroundColor Red
        Write-Host '    The server is probably off - ask your friend to start it.' -ForegroundColor Yellow
        Write-Host '    (If it uses Tailscale, make sure Tailscale is running on your PC.)' -ForegroundColor Yellow
        Read-Host 'Press Enter to close'; return
    }
    $cfg = Join-Path $Base 'client-config.json'
    Write-ClientConfig $cfg $info
    $jar = Ensure-Client
    Launch-Client $jar $cfg
}
catch {
    Write-Host ''
    Write-Host 'Something went wrong. Send a screenshot of this window to whoever runs the server.' -ForegroundColor Yellow
    Read-Host 'Press Enter to close'
}
