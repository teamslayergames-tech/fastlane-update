package BasicInputQOL

import plugin.Plugin
import plugin.annotations.PluginMeta
import plugin.api.*
import rt4.Keyboard
import java.awt.event.*
import javax.swing.SwingUtilities

class plugin : Plugin() {
    private var cameraDebugEnabled = false
    private var mouseDebugEnabled = false

    companion object {
        private var lastMouseWheelX = 0
        private var lastMouseWheelY = 0
        private val defaultCameraPYZ = Triple(128.0, 0.0, 600)
    }

    override fun Init() {
        API.AddMouseListener(MouseCallbacks)
        API.AddMouseWheelListener(MouseWheelCallbacks)
    }

    override fun ProcessCommand(commandStr: String?, args: Array<out String>?) {
        commandStr ?: return
        if (API.PlayerHasPrivilege(Privileges.JMOD)) {
            when(commandStr) {
                "::mousedebug" -> mouseDebugEnabled = !mouseDebugEnabled
                "::cameradebug" -> cameraDebugEnabled = !cameraDebugEnabled
            }
        }
    }

    override fun Draw(timeDelta: Long) {
        if (mouseDebugEnabled) {
            API.DrawText(
                FontType.SMALL,
                FontColor.YELLOW,
                TextModifier.LEFT,
                "Mouse Coords: (${API.GetMouseX()}, ${API.GetMouseY()})",
                10,
                40
            )
        }
        if (cameraDebugEnabled) {
            API.DrawText(
                FontType.SMALL,
                FontColor.YELLOW,
                TextModifier.LEFT,
                "Camera: [P=${API.GetCameraPitch()}, Y=${API.GetCameraYaw()}, Z=${API.GetCameraZoom()}]",
                10,
                50
            )
        }
    }

    object MouseWheelCallbacks : MouseWheelListener {
        override fun mouseWheelMoved(e: MouseWheelEvent?) {
            e ?: return
            if (!API.IsLoggedIn()) return
            // FastLane: scroll zooms whenever the mouse is over the game world
            // (not over the chatbox, side tabs or minimap, so those still scroll normally)
            if (!isOverGameView(e.x, e.y) && !API.IsKeyPressed(Keyboard.KEY_SHIFT) && !API.IsKeyPressed(Keyboard.KEY_CTRL)) return
            // FastLane: a window like the bank, a shop or the Fast Exchange is open, so let the wheel scroll it instead
            if (isMainWindowOpen() && !API.IsKeyPressed(Keyboard.KEY_SHIFT) && !API.IsKeyPressed(Keyboard.KEY_CTRL)) return
            val rot = e.wheelRotation
            if (rot == 0) return
            API.SetCameraZoom((API.GetCameraZoom() + rot * 40).coerceIn(250, 1300))
        }

        /** true while a non-walkable window is open in the main game area (fixed 548:11, resizable 746:6) */
        private fun isMainWindowOpen(): Boolean {
            return try {
                for (parent in longArrayOf((548L shl 16) or 11L, (746L shl 16) or 6L)) {
                    val ptr = rt4.InterfaceList.openInterfaces.get(parent) as? rt4.ComponentPointer
                    if (ptr != null && ptr.type == 0) return true
                }
                false
            } catch (t: Throwable) { false }
        }

        private fun isOverGameView(x: Int, y: Int): Boolean {
            if (API.GetWindowMode() == WindowMode.FIXED) {
                return x in 4..515 && y in 4..337
            }
            val d = API.GetWindowDimensions()
            val w = d.width
            val h = d.height
            if (x < 520 && y > h - 165) return false          // chatbox
            if (x > w - 245 && y > h - 340) return false      // side tabs / inventory
            if (x > w - 215 && y < 175) return false          // minimap
            return true
        }
    }

    object MouseCallbacks : MouseAdapter() {
        override fun mouseDragged(e: MouseEvent?) {
           e ?: return
           if (SwingUtilities.isMiddleMouseButton(e)) {
               val x = e.x
               val y = e.y
               val accelX = lastMouseWheelX - x
               val accelY = lastMouseWheelY - y
               lastMouseWheelX = x
               lastMouseWheelY = y
               API.UpdateCameraYaw(accelX * 2.0)
               API.UpdateCameraPitch(-accelY * 2.0)
           }
        }

        override fun mouseClicked(e: MouseEvent?) {
            e ?: return

/*            val width = API.GetWindowDimensions().width;
            val compassBordersX = intArrayOf(width - 165, width - 125)
            val compassBordersY = intArrayOf(0, 45)

            if (
                e.x in compassBordersX[0]..compassBordersX[1]
                && e.y in compassBordersY[0]..compassBordersY[1]
            )
            {
                API.SetCameraPitch(defaultCameraPYZ.first)
                API.SetCameraYaw(defaultCameraPYZ.second)
            }*/
        }

        override fun mousePressed(e: MouseEvent?) {
            e ?: return
            if (SwingUtilities.isMiddleMouseButton(e)) {
                lastMouseWheelX = e.x
                lastMouseWheelY = e.y
            }
        }
    }
}