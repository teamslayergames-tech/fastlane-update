package CompassNorth

import plugin.Plugin
import plugin.api.API
import rt4.Camera
import rt4.Component
import rt4.ComponentPointer
import rt4.InterfaceList
import java.awt.event.MouseAdapter
import java.awt.event.MouseEvent
import javax.swing.SwingUtilities

/**
 * Click the compass to turn the camera back to north.
 * v1.1: the click is caught by a mouse listener and handled every frame in Draw(). (v1.0 checked in Update(),
 * which the client only calls about once every 20 seconds, so clicks were almost always missed.)
 * Finds the compass (client code 1339) in whichever game frame is open (fixed or resizable) and works out where it is on screen.
 */
class plugin : Plugin() {
    @Volatile private var clickX = -1
    @Volatile private var clickY = -1

    override fun Init() {
        API.AddMouseListener(object : MouseAdapter() {
            override fun mousePressed(e: MouseEvent?) {
                if (e != null && SwingUtilities.isLeftMouseButton(e)) { clickX = e.x; clickY = e.y }
            }
        })
    }

    override fun Draw(timeDelta: Long) {
        val x = clickX; val y = clickY
        if (x < 0) return
        clickX = -1; clickY = -1
        val r = compassRect() ?: return
        if (x >= r[0] && y >= r[1] && x < r[0] + r[2] && y < r[1] + r[3]) Camera.yawTarget = 0.0
    }

    private fun compassRect(): IntArray? {
        val all = InterfaceList.components ?: return null
        for (iface in all.indices) {
            val comps = all[iface] ?: continue
            for (c in comps) {
                if (c == null || c.clientCode != 1339 || c.hidden) continue
                val pos = absolute(c, all) ?: continue
                return intArrayOf(pos[0], pos[1], c.width, c.height)
            }
        }
        return null
    }

    /** screen position = own x/y + every parent's x/y minus its scroll, following sub-interfaces to their host component */
    private fun absolute(start: Component, all: Array<Array<Component?>?>): IntArray? {
        var x = start.x; var y = start.y
        var c = start; var guard = 0
        while (guard++ < 30) {
            val layer = c.overlayer
            val parent: Component? = if (layer != -1) {
                all.getOrNull(layer ushr 16)?.getOrNull(layer and 0xFFFF)
            } else {
                val iface = c.id ushr 16
                if (iface == InterfaceList.topLevelInterface) return intArrayOf(x, y)
                hostOf(iface)
            }
            val p = parent ?: return null
            if (p.hidden) return null
            x += p.x - p.scrollX; y += p.y - p.scrollY
            c = p
        }
        return null
    }

    private fun hostOf(iface: Int): Component? {
        var ptr = InterfaceList.openInterfaces.head() as? ComponentPointer
        while (ptr != null) {
            if (ptr.interfaceId == iface) return InterfaceList.getComponent(ptr.key.toInt())
            ptr = InterfaceList.openInterfaces.next() as? ComponentPointer
        }
        return null
    }
}
