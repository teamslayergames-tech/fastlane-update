package CompassNorth

import plugin.Plugin
import rt4.Camera
import rt4.Component
import rt4.ComponentPointer
import rt4.InterfaceList
import rt4.Mouse

/**
 * Click the compass to turn the camera back to north.
 * Runs on the game thread: it uses the client's own click position, and finds the compass (client code 1339)
 * in whichever game frame is open (fixed or resizable), working out where it is on screen.
 */
class plugin : Plugin() {
    override fun Update() {
        if (Mouse.clickButton != 1) return
        val r = compassRect() ?: return
        val x = Mouse.clickX; val y = Mouse.clickY
        if (x >= r[0] && y >= r[1] && x < r[0] + r[2] && y < r[1] + r[3]) Camera.yawTarget = 0.0
    }

    private fun compassRect(): IntArray? {
        val all = InterfaceList.components ?: return null
        for (iface in all.indices) {
            val comps = all[iface] ?: continue
            for (c in comps) {
                if (c == null || c.clientCode != 1339 || c.hidden) continue
                val pos = absolute(c, all) ?: continue
                return intArrayOf(pos[0], pos[1], c.width, c.height)
            }
        }
        return null
    }

    /** screen position = own x/y + every parent's x/y minus its scroll, following sub-interfaces to their host component */
    private fun absolute(start: Component, all: Array<Array<Component?>?>): IntArray? {
        var x = start.x; var y = start.y
        var c = start; var guard = 0
        while (guard++ < 30) {
            val layer = c.overlayer
            val parent: Component? = if (layer != -1) {
                all.getOrNull(layer ushr 16)?.getOrNull(layer and 0xFFFF)
            } else {
                val iface = c.id ushr 16
                if (iface == InterfaceList.topLevelInterface) return intArrayOf(x, y)
                hostOf(iface)
            }
            val p = parent ?: return null
            if (p.hidden) return null
            x += p.x - p.scrollX; y += p.y - p.scrollY
            c = p
        }
        return null
    }

    private fun hostOf(iface: Int): Component? {
        var ptr = InterfaceList.openInterfaces.head() as? ComponentPointer
        while (ptr != null) {
            if (ptr.interfaceId == iface) return InterfaceList.getComponent(ptr.key.toInt())
            ptr = InterfaceList.openInterfaces.next() as? ComponentPointer
        }
        return null
    }
}
