package EscClose

import plugin.Plugin
import plugin.api.API
import java.awt.event.KeyAdapter
import java.awt.event.KeyEvent

/**
 * Press Esc to close the open window or dialogue.
 * FastLane: the close command is sent from the game thread, and only while logged in (sending it from the keyboard
 * thread could clash with the game's own packets).
 */
class plugin : Plugin() {
    @Volatile private var pending = false

    override fun Init() {
        API.AddKeyboardListener(object : KeyAdapter() {
            override fun keyPressed(e: KeyEvent) {
                if (e.keyCode == KeyEvent.VK_ESCAPE) pending = true
            }
        })
    }

    override fun Draw(timeDelta: Long) {
        if (!pending) return
        pending = false
        if (API.IsLoggedIn()) API.DispatchCommand("::xface")
    }
}
