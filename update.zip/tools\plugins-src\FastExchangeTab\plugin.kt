package FastExchangeTab

import plugin.Plugin
import plugin.api.API
import plugin.api.MiniMenuEntry
import rt4.Component
import rt4.Sprite

/**
 * A Fast Exchange button on the minimap, between the compass and the world map globe.
 * Left-click opens the Fast Exchange (::fe). Works in fixed and resizable mode.
 */
class plugin : Plugin() {
    // fixed mode (548): compass, world map, and the last minimap pieces drawn on top of the map frame
    private val FIXED_COMPASS = id(548, 65)
    private val FIXED_WORLDMAP = id(548, 66)
    private val FIXED_TOP = setOf(id(548, 67), id(548, 68))
    // resizable mode (746): compass and world map (the world map is drawn last)
    private val RESIZABLE_COMPASS = id(746, 10)
    private val RESIZABLE_WORLDMAP = id(746, 110)

    private val SIZE = 34

    private var compassX = -1; private var compassY = -1; private var compassH = 0
    private var mapX = -1; private var mapY = -1
    private var btnX = -1; private var btnY = -1
    private var lastDrawn = 0L
    private var icon: Sprite? = null

    private fun id(iface: Int, child: Int) = (iface shl 16) or child

    override fun ComponentDraw(componentIndex: Int, component: Component?, screenX: Int, screenY: Int) {
        val c = component ?: return
        when (c.id) {
            FIXED_COMPASS, RESIZABLE_COMPASS -> { compassX = screenX; compassY = screenY; compassH = c.height }
            FIXED_WORLDMAP -> { mapX = screenX; mapY = screenY }
            RESIZABLE_WORLDMAP -> {
                mapX = screenX; mapY = screenY
                // resizable: the globe is bottom-right of the map, so sit just left of the compass instead
                if (compassX >= 0) draw(compassX - SIZE - 4, compassY)
            }
            in FIXED_TOP -> {
                // fixed: centred in the gap between the compass and the globe
                if (compassX >= 0 && mapY > compassY) draw(mapX, (compassY + compassH + mapY) / 2 - SIZE / 2)
            }
        }
    }

    private fun draw(x: Int, y: Int) {
        btnX = x; btnY = y; lastDrawn = System.currentTimeMillis()
        if (icon == null) icon = try { API.GetObjSprite(995, 10000, false, 1, 3153952) } catch (e: Exception) { null }
        if (hovered()) API.FillRect(x + 2, y + 2, SIZE - 4, SIZE - 4, 0xFFFFFF, 40)
        icon?.render(x + (SIZE - 36) / 2, y + (SIZE - 32) / 2)
    }

    private fun hovered(): Boolean {
        val mx = API.GetMouseX(); val my = API.GetMouseY()
        return btnX >= 0 && mx >= btnX && mx < btnX + SIZE && my >= btnY && my < btnY + SIZE
    }

    override fun OnMiniMenuCreate(currentEntries: Array<out MiniMenuEntry>?) {
        // the minimap normally redraws every frame; if it hasn't been drawn lately the button isn't on screen
        val visible = System.currentTimeMillis() - lastDrawn < 1000
        if (!visible || !API.IsLoggedIn() || !hovered()) return
        API.InsertMiniMenuEntry("Open", "<col=ff9040>Fast Exchange", Runnable { API.DispatchCommand("::fe") })
    }

    override fun OnLogout() { btnX = -1; compassX = -1; mapX = -1 }
}
