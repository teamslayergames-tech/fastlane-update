package FastExchangeTab

import plugin.Plugin
import plugin.api.API
import plugin.api.MiniMenuEntry
import rt4.Component
import rt4.Sprite

/**
 * The follower (summoning) tab is blank until a familiar is summoned.
 * While it's blank, this shows a coins icon there and makes clicking it open the Fast Exchange (::fe).
 * With a familiar out, the tab works exactly as normal.
 */
class plugin : Plugin() {
    private val FIXED_TAB = (548 shl 16) or 20      // follower tab, fixed mode
    private val RESIZABLE_TAB = (746 shl 16) or 48  // follower tab, resizable mode
    private val FAMILIAR_VARP = 448                 // summoning pouch id while a familiar/pet is out

    private var familiarOut = false
    private var icon: Sprite? = null

    override fun OnLogin() { familiarOut = false }

    override fun OnVarpUpdate(id: Int, value: Int) {
        if (id == FAMILIAR_VARP) familiarOut = value > 0
    }

    override fun ComponentDraw(componentIndex: Int, component: Component?, screenX: Int, screenY: Int) {
        if (familiarOut || component == null) return
        if (component.id != FIXED_TAB && component.id != RESIZABLE_TAB) return
        if (icon == null) icon = try { API.GetObjSprite(995, 10000, false, 1, 3153952) } catch (e: Exception) { null }
        val sprite = icon ?: return
        sprite.render(screenX + (component.width - 36) / 2, screenY + (component.height - 32) / 2)
    }

    override fun OnMiniMenuCreate(currentEntries: Array<out MiniMenuEntry>?) {
        if (familiarOut || currentEntries == null) return
        if (currentEntries.any { it.verb == "Follower Details" })
            API.InsertMiniMenuEntry("Open", "<col=ff9040>Fast Exchange", Runnable { API.DispatchCommand("::fe") })
    }
}
