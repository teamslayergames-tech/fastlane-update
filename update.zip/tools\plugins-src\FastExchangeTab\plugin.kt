package FastExchangeTab

import plugin.Plugin
import plugin.api.API
import plugin.api.MiniMenuEntry
import rt4.Component
import rt4.Sprite

/**
 * A Fast Exchange button on the minimap, between the compass and the world map globe.
 * Left-click opens the Fast Exchange (::fe). Works in fixed and resizable mode.
 *
 * The client draws the compass with special code that never tells plugins where it is,
 * so the button is placed relative to the world map globe (which does), using the
 * compass's fixed offset from the globe in each layout.
 */
class plugin : Plugin() {
    private val FIXED_WORLDMAP = id(548, 66)                  // globe, fixed mode
    private val FIXED_TOP = setOf(id(548, 67), id(548, 68))   // drawn after the map frame, so the button stays on top
    private val RESIZABLE_WORLDMAP = id(746, 110)             // globe, resizable mode (drawn last)

    private val SIZE = 34

    private var mapX = -1; private var mapY = -1
    private var btnX = -1; private var btnY = -1
    private var lastDrawn = 0L
    private var icon: Sprite? = null

    private fun id(iface: Int, child: Int) = (iface shl 16) or child

    override fun ComponentDraw(componentIndex: Int, component: Component?, screenX: Int, screenY: Int) {
        val c = component ?: return
        when (c.id) {
            FIXED_WORLDMAP -> { mapX = screenX; mapY = screenY }
            // fixed: compass is at globe + (1, -116), 33 tall, so centre the button in the gap between them
            in FIXED_TOP -> if (mapX >= 0) draw(mapX, mapY - 59)
            // resizable: the globe is bottom-right of the map; the compass is at globe + (-125, -129). Sit just left of it.
            RESIZABLE_WORLDMAP -> draw(screenX - 125 - SIZE - 4, screenY - 129)
        }
    }

    private fun draw(x: Int, y: Int) {
        btnX = x; btnY = y; lastDrawn = System.currentTimeMillis()
        if (icon == null) icon = try { API.GetObjSprite(995, 10000, false, 1, 3153952) } catch (e: Exception) { null }
        if (hovered()) API.FillRect(x + 2, y + 2, SIZE - 4, SIZE - 4, 0xFFFFFF, 40)
        icon?.render(x + (SIZE - 36) / 2, y + (SIZE - 32) / 2)
    }

    private fun hovered(): Boolean {
        val mx = API.GetMouseX(); val my = API.GetMouseY()
        return btnX >= 0 && mx >= btnX && mx < btnX + SIZE && my >= btnY && my < btnY + SIZE
    }

    override fun OnMiniMenuCreate(currentEntries: Array<out MiniMenuEntry>?) {
        // the minimap normally redraws every frame; if it hasn't been drawn lately the button isn't on screen
        val visible = System.currentTimeMillis() - lastDrawn < 1000
        if (!visible || !API.IsLoggedIn() || !hovered()) return
        API.InsertMiniMenuEntry("Open", "<col=ff9040>Fast Exchange", Runnable { API.DispatchCommand("::fe") })
    }

    override fun OnLogout() { btnX = -1; mapX = -1 }
}
