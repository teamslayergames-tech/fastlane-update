package FreezeWatch

import plugin.Plugin

/**
 * Freeze watch: the game draws many times a second. If it stops drawing for 15 seconds, this writes every thread's
 * stack trace to the client log (logs folder) once, so a freeze can be traced to its cause.
 */
class plugin : Plugin() {
    companion object {
        @Volatile var lastDraw = System.currentTimeMillis()
        @Volatile var started = false
        @Volatile var reported = false
    }

    override fun Init() {
        lastDraw = System.currentTimeMillis()
        if (started) return // survives plugin reloads: only one watcher thread
        started = true
        val t = Thread({
            while (true) {
                try { Thread.sleep(5000) } catch (e: InterruptedException) { return@Thread }
                val stalled = System.currentTimeMillis() - lastDraw
                val minimized = try { java.awt.Frame.getFrames().any { it.isVisible && (it.extendedState and java.awt.Frame.ICONIFIED) != 0 } } catch (e: Exception) { false }
                if (stalled > 15000 && !reported && !minimized) {
                    reported = true
                    val sb = StringBuilder("==== FastLane FreezeWatch: the game has not drawn for ${stalled / 1000}s - thread dump ====\n")
                    for ((th, stack) in Thread.getAllStackTraces()) {
                        sb.append("\"${th.name}\" state=${th.state}\n")
                        for (el in stack.take(40)) sb.append("    at ").append(el).append('\n')
                    }
                    sb.append("==== end of thread dump ====")
                    System.out.println(sb); System.out.flush()
                } else if (stalled < 5000) {
                    reported = false
                }
            }
        }, "FastLane-FreezeWatch")
        t.isDaemon = true
        t.start()
    }

    override fun LateDraw(timeDelta: Long) { lastDraw = System.currentTimeMillis() } // runs every frame, on every screen
}
