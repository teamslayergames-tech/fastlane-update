package SpaceContinue

import plugin.Plugin
import plugin.api.API
import rt4.Component
import rt4.ComponentPointer
import rt4.Cs1ScriptRunner
import rt4.InterfaceList
import rt4.MiniMenu
import java.awt.event.KeyAdapter
import java.awt.event.KeyEvent

/**
 * Space bar = "Click here to continue" (NPC chat, player chat, messages, level-ups).
 * v1.1: also finds the newer-style (IF3) continue buttons, which is what every chat dialog in this cache uses.
 * The key is only noted on the keyboard thread; the click is sent from the game thread in Draw().
 */
class plugin : Plugin() {
    @Volatile private var pressed = false

    override fun Init() {
        API.AddKeyboardListener(object : KeyAdapter() {
            override fun keyPressed(e: KeyEvent?) {
                if (e != null && e.keyCode == KeyEvent.VK_SPACE) pressed = true
            }
        })
    }

    override fun Draw(timeDelta: Long) {
        if (!pressed) return
        pressed = false
        if (Cs1ScriptRunner.pleaseWaitComponent != null) return
        val c = findContinue() ?: return
        val sub = c.createdComponentId
        MiniMenu.sendComponentClickPacket(sub, c.id)          // same packet the client sends for a "Continue" click
        Cs1ScriptRunner.pleaseWaitComponent = InterfaceList.getComponent(c.id, sub) ?: c
        InterfaceList.redraw(Cs1ScriptRunner.pleaseWaitComponent)
    }

    private fun isContinue(c: Component): Boolean =
        c.buttonType == 6 || InterfaceList.getServerActiveProperties(c).isResumePauseButtonEnabled()

    private fun findContinue(): Component? {
        val all = InterfaceList.components ?: return null
        var ptr = InterfaceList.openInterfaces.head() as? ComponentPointer
        while (ptr != null) {
            val id = ptr.interfaceId
            if (id >= 0 && id < all.size) {
                all[id]?.forEach { c -> if (c != null && !c.hidden && isContinue(c) && !parentHidden(c, all)) return c }
            }
            ptr = InterfaceList.openInterfaces.next() as? ComponentPointer
        }
        return null
    }

    private fun parentHidden(c: Component, all: Array<Array<Component?>?>): Boolean {
        var layer = c.overlayer
        var guard = 0
        while (layer != -1 && guard++ < 20) {
            val p = all.getOrNull(layer ushr 16)?.getOrNull(layer and 0xFFFF) ?: return false
            if (p.hidden) return true
            layer = p.overlayer
        }
        return false
    }
}
