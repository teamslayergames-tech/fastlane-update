package SpaceContinue

import plugin.Plugin
import plugin.api.API
import rt4.Component
import rt4.ComponentPointer
import rt4.Cs1ScriptRunner
import rt4.InterfaceList
import rt4.MiniMenu
import java.awt.event.KeyAdapter
import java.awt.event.KeyEvent

/**
 * Space bar = "Click here to continue" (NPC chat, level-ups, messages).
 * The key is only noted on the keyboard thread; the click is sent from the game thread in Draw().
 */
class plugin : Plugin() {
    @Volatile private var pressed = false

    override fun Init() {
        API.AddKeyboardListener(object : KeyAdapter() {
            override fun keyPressed(e: KeyEvent?) {
                if (e != null && e.keyCode == KeyEvent.VK_SPACE) pressed = true
            }
        })
    }

    override fun Draw(timeDelta: Long) {
        if (!pressed) return
        pressed = false
        if (Cs1ScriptRunner.pleaseWaitComponent != null) return
        val c = findContinue() ?: return
        MiniMenu.sendComponentClickPacket(-1, c.id)
        Cs1ScriptRunner.pleaseWaitComponent = c
        InterfaceList.redraw(c)
    }

    private fun findContinue(): Component? {
        val all = InterfaceList.components ?: return null
        var ptr = InterfaceList.openInterfaces.head() as? ComponentPointer
        while (ptr != null) {
            val id = ptr.interfaceId
            if (id >= 0 && id < all.size) {
                all[id]?.forEach { c -> if (c != null && c.buttonType == 6 && !c.hidden && !parentHidden(c, all)) return c }
            }
            ptr = InterfaceList.openInterfaces.next() as? ComponentPointer
        }
        return null
    }

    private fun parentHidden(c: Component, all: Array<Array<Component?>?>): Boolean {
        var layer = c.overlayer
        var guard = 0
        while (layer != -1 && guard++ < 20) {
            val p = all.getOrNull(layer ushr 16)?.getOrNull(layer and 0xFFFF) ?: return false
            if (p.hidden) return true
            layer = p.overlayer
        }
        return false
    }
}
