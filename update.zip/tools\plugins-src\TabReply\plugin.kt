package TabReply

import plugin.Plugin
import plugin.api.API
import java.awt.event.KeyAdapter
import java.awt.event.KeyEvent

/**
 * Press Tab to reply to your last private message.
 * FastLane: the reply is sent from the game thread (sending it from the keyboard thread could clash with the game's own
 * packets), and only while logged in (pressing Tab on the login screen used to throw an error).
 */
class plugin : Plugin() {
    @Volatile private var pending = false

    override fun Init() {
        API.AddKeyboardListener(object : KeyAdapter() {
            override fun keyPressed(e: KeyEvent) {
                if (e.keyCode == KeyEvent.VK_TAB) pending = true
            }
        })
    }

    override fun Draw(timeDelta: Long) {
        if (!pending) return
        pending = false
        if (API.IsLoggedIn()) API.DispatchCommand("::reply")
    }
}
