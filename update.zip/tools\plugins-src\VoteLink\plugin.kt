package VoteLink

import plugin.Plugin
import rt4.Player

/**
 * ::vote opens the player's own TopG voting page in their web browser, with their username already in the link
 * (so the server knows who to reward). The server also answers ::vote in chat with the link and their vote points.
 */
class plugin : Plugin() {
    private val SITE_ID = "687958"

    override fun ProcessCommand(commandStr: String?, args: Array<out String>?) {
        if (commandStr == null || !commandStr.equals("::vote", true)) return
        val name = Player.usernameInput.toString().trim().replace(" ", "_").replace(Regex("[^A-Za-z0-9_]"), "")
        val url = "https://topg.org/runescape-private-servers/server-$SITE_ID-$name#vote"
        Thread {
            try {
                if (java.awt.Desktop.isDesktopSupported()) java.awt.Desktop.getDesktop().browse(java.net.URI(url))
                else Runtime.getRuntime().exec(arrayOf("rundll32", "url.dll,FileProtocolHandler", url))
            } catch (e: Throwable) {
                try { Runtime.getRuntime().exec(arrayOf("rundll32", "url.dll,FileProtocolHandler", url)) } catch (e2: Throwable) {}
            }
        }.start()
    }
}
